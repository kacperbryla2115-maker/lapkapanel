LarpClient - mod klienta Fabric (Java Edition, Minecraft 1.21.4)

P - otwiera / zamyka czarno-fioletowy panel (zmiana klawisza: Opcje > Sterowanie > LarpClient).

Zakladki:
  Mody - przelaczniki: FPS, Ping, Koordy (XYZ), CPS, Czas. Wlaczone elementy
         pokazuja sie na ekranie.
  GUI  - podglad ekranu: przeciagnij elementy myszka w dowolne miejsce.
         "Resetuj pozycje" przywraca domyslne.

Config: .minecraft/config/larpclient.json
Wynik buildu: build/libs/larpclient-1.0.0.jar (plik -sources.jar nie jest potrzebny)
