package pl.larpclient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class LarpClient implements ClientModInitializer {

    /** Opis modułu widocznego w panelu. */
    public record Mod(String id, String name, String desc, double defFx, double defFy) {}

    /** Zapisywany stan modułu: włączony + pozycja jako ułamek ekranu (0..1). */
    public static class State {
        public boolean enabled = false;
        public double fx = 0.0;
        public double fy = 0.0;
    }

    public static class Config {
        public Map<String, State> modules = new LinkedHashMap<>();
    }

    public static final List<Mod> MODS = List.of(
            new Mod("fps", "FPS", "Pokazuje liczbę klatek na sekundę.", 0.005, 0.01),
            new Mod("ping", "Ping", "Pokazuje Twój ping do serwera.", 0.005, 0.07),
            new Mod("coords", "Koordy", "Pokazuje Twoje koordynaty X Y Z.", 0.005, 0.13),
            new Mod("cps", "CPS", "Kliknięcia lewym przyciskiem na sekundę.", 0.005, 0.19),
            new Mod("time", "Czas", "Pokazuje aktualną godzinę.", 0.005, 0.25)
    );

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH =
            FabricLoader.getInstance().getConfigDir().resolve("larpclient.json");

    private static Config config = new Config();
    private static KeyBinding openKey;

    public static KeyBinding openKey() { return openKey; }

    @Override
    public void onInitializeClient() {
        loadConfig();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.larpclient.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_P, "category.larpclient"));

        // Uruchamiane na koncu ticka, wiec wygrywa z domyslnym "P" (interakcje spoleczne).
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.wasPressed()) {
                if (mc.currentScreen == null && mc.player != null) {
                    mc.setScreen(new LarpScreen());
                }
            }
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> renderHud(ctx));
    }

    // ------------------------------------------------------------------
    // Stan i konfiguracja
    // ------------------------------------------------------------------

    public static Mod mod(String id) {
        for (Mod m : MODS) if (m.id().equals(id)) return m;
        throw new IllegalArgumentException(id);
    }

    public static State state(String id) {
        return config.modules.computeIfAbsent(id, k -> {
            State s = new State();
            Mod m = mod(k);
            s.fx = m.defFx();
            s.fy = m.defFy();
            return s;
        });
    }

    public static void resetPositions() {
        for (Mod m : MODS) {
            State s = state(m.id());
            s.fx = m.defFx();
            s.fy = m.defFy();
        }
        save();
    }

    private static void loadConfig() {
        try {
            if (Files.exists(CONFIG_PATH)) {
                Config c = GSON.fromJson(Files.readString(CONFIG_PATH), Config.class);
                if (c != null && c.modules != null) config = c;
            }
        } catch (Exception e) {
            System.err.println("[LarpClient] Nie mogę wczytać configu: " + e);
        }
        for (Mod m : MODS) state(m.id()); // uzupelnij brakujace
        save();
    }

    public static void save() {
        try {
            Files.writeString(CONFIG_PATH, GSON.toJson(config));
        } catch (IOException e) {
            System.err.println("[LarpClient] Nie mogę zapisać configu: " + e);
        }
    }

    // ------------------------------------------------------------------
    // HUD
    // ------------------------------------------------------------------

    public static int ping(MinecraftClient mc) {
        if (mc.player == null || mc.getNetworkHandler() == null) return -1;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return e == null ? -1 : e.getLatency();
    }

    // --- CPS ---
    private static final Deque<Long> clicks = new ArrayDeque<>();
    private static boolean lmbDown = false;

    private static void trackClicks(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        boolean down = mc.currentScreen == null
                && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (down && !lmbDown) clicks.addLast(now);
        lmbDown = down;
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
    }

    public static String valueText(String id, MinecraftClient mc) {
        switch (id) {
            case "fps":
                return "FPS " + mc.getCurrentFps();
            case "ping": {
                int p = ping(mc);
                return p < 0 ? "Ping --" : "Ping " + p + " ms";
            }
            case "coords": {
                if (mc.player == null) return "XYZ --";
                return "XYZ " + (int) Math.floor(mc.player.getX()) + " "
                        + (int) Math.floor(mc.player.getY()) + " "
                        + (int) Math.floor(mc.player.getZ());
            }
            case "cps":
                return "CPS " + clicks.size();
            case "time":
                return LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
            default:
                return id;
        }
    }

    private static void renderHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;

        trackClicks(mc);
        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        for (Mod m : MODS) {
            State s = state(m.id());
            if (!s.enabled) continue;

            String t = valueText(m.id(), mc);
            int w = tr.getWidth(t) + 9;
            int h = 9 + 6;
            int x = (int) Math.round(s.fx * (sw - w));
            int y = (int) Math.round(s.fy * (sh - h));

            ctx.fill(x, y, x + w, y + h, 0xB00D0618);        // tlo
            ctx.fill(x, y, x + 2, y + h, 0xFFB66DFF);        // fioletowy pasek
            ctx.drawTextWithShadow(tr, Text.literal(t), x + 5, y + 3, 0xFFF1E4FF);
        }
    }
}
