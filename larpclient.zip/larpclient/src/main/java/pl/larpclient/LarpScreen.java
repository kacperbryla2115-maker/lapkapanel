package pl.larpclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

/** Panel otwierany klawiszem P (czarno-fioletowy). Zakladki: Mody i GUI. */
public class LarpScreen extends Screen {

    private static final int HEADER = 22;
    private static final int SIDE = 84;
    private static final int CHIP_W = 40;
    private static final int CHIP_H = 12;

    // kolory (ARGB)
    private static final int OVERLAY = 0x99000000;
    private static final int BORDER = 0xFF7B2FF7;
    private static final int BODY = 0xF2090510;
    private static final int HEAD = 0xFF170A2B;
    private static final int SIDEBAR = 0xFF0F0619;
    private static final int ACCENT = 0xFFB66DFF;
    private static final int TEXT = 0xFFEBDDFF;
    private static final int MUTED = 0xFF9A86B8;
    private static final int CARD = 0xFF150C22;
    private static final int CARD_HOVER = 0xFF1F1334;

    private static final String[] TABS = {"Mody", "GUI"};
    private static final List<LarpClient.Mod> MODS = LarpClient.MODS;

    private int tab = 0;
    private String dragging = null;
    private int grabDx, grabDy;
    private int px, py, pw, ph;

    public LarpScreen() {
        super(Text.literal("LarpClient"));
    }

    @Override
    protected void init() {
        pw = Math.min(width - 16, 380);
        ph = Math.min(height - 16, 250);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
    }

    // ------------------------------------------------------------------
    // Uklad
    // ------------------------------------------------------------------

    private int cx() { return px + SIDE + 10; }
    private int cy() { return py + HEADER + 10; }
    private int cw() { return pw - SIDE - 20; }
    private int ch() { return ph - HEADER - 20; }
    private int rowY(int i) { return cy() + 18 + i * 36; }
    private int tabY(int i) { return py + HEADER + 10 + i * 26; }

    private int[] preview() {
        int availW = cw();
        int availH = ch() - 26 - 22;
        int w = availW;
        int h = Math.round(w * (float) height / width);
        if (h > availH) {
            h = availH;
            w = Math.round(h * (float) width / height);
        }
        int x = cx() + (cw() - w) / 2;
        int y = cy() + 26;
        return new int[]{x, y, w, h};
    }

    private int[] chipPos(int[] p, LarpClient.State s) {
        int x = p[0] + (int) Math.round(s.fx * (p[2] - CHIP_W));
        int y = p[1] + (int) Math.round(s.fy * (p[3] - CHIP_H));
        return new int[]{x, y};
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ------------------------------------------------------------------
    // Rysowanie
    // ------------------------------------------------------------------

    private void box(DrawContext c, int x, int y, int w, int h, int fill, int border) {
        c.fill(x, y, x + w, y + h, border);
        c.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
    }

    private void txt(DrawContext c, String s, int x, int y, int color) {
        c.drawTextWithShadow(textRenderer, Text.literal(s), x, y, color);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, OVERLAY);

        // ramka panelu
        box(c, px, py, pw, ph, BODY, BORDER);

        // naglowek z nazwa w lewym gornym rogu panelu
        c.fill(px + 1, py + 1, px + pw - 1, py + HEADER, HEAD);
        c.fill(px + 1, py + HEADER, px + pw - 1, py + HEADER + 1, BORDER);
        txt(c, "LarpClient", px + 8, py + 7, ACCENT);

        boolean hoverX = inside(mx, my, px + pw - 18, py + 5, 12, 12);
        txt(c, "x", px + pw - 15, py + 7, hoverX ? 0xFFFFFFFF : MUTED);

        // pasek zakladek
        c.fill(px + 1, py + HEADER + 1, px + SIDE, py + ph - 1, SIDEBAR);
        c.fill(px + SIDE, py + HEADER + 1, px + SIDE + 1, py + ph - 1, 0xFF2A1450);
        for (int i = 0; i < TABS.length; i++) {
            int x = px + 6, y = tabY(i), w = SIDE - 12, h = 22;
            boolean sel = tab == i;
            boolean hov = inside(mx, my, x, y, w, h);
            if (sel) {
                c.fill(x, y, x + w, y + h, 0xFF2A0E52);
                c.fill(x, y, x + 2, y + h, ACCENT);
            } else if (hov) {
                c.fill(x, y, x + w, y + h, 0xFF1D0B38);
            }
            txt(c, TABS[i], x + 10, y + 7, sel ? 0xFFFFFFFF : MUTED);
        }

        if (tab == 0) renderMods(c, mx, my);
        else renderGui(c, mx, my);
    }

    private void renderMods(DrawContext c, int mx, int my) {
        txt(c, "Mody", cx(), cy(), ACCENT);

        for (int i = 0; i < MODS.size(); i++) {
            LarpClient.Mod m = MODS.get(i);
            LarpClient.State s = LarpClient.state(m.id());
            int x = cx(), y = rowY(i), w = cw(), h = 32;

            boolean hov = inside(mx, my, x, y, w, h);
            box(c, x, y, w, h, hov ? CARD_HOVER : CARD, 0xFF2A1450);
            txt(c, m.name(), x + 8, y + 7, TEXT);
            txt(c, m.desc(), x + 8, y + 19, MUTED);

            // przelacznik
            int sx = x + w - 36, sy = y + 9;
            c.fill(sx, sy, sx + 28, sy + 14, s.enabled ? 0xFF7B2FF7 : 0xFF2B1E3D);
            int kx = s.enabled ? sx + 16 : sx + 2;
            c.fill(kx, sy + 2, kx + 10, sy + 12, s.enabled ? 0xFFFFFFFF : 0xFF8A7AA8);
        }
    }

    private void renderGui(DrawContext c, int mx, int my) {
        txt(c, "GUI", cx(), cy(), ACCENT);
        txt(c, "Przeciągnij elementy tam, gdzie chcesz je mieć.", cx(), cy() + 12, MUTED);

        int[] p = preview();
        box(c, p[0], p[1], p[2], p[3], 0xFF05030A, BORDER);

        // slad paska skrotow, zeby bylo wiadomo, gdzie jest dol ekranu
        float scale = p[2] / (float) width;
        int hbW = Math.max(10, Math.round(182 * scale));
        int hbH = Math.max(3, Math.round(22 * scale));
        int hbX = p[0] + (p[2] - hbW) / 2;
        c.fill(hbX, p[1] + p[3] - hbH - 1, hbX + hbW, p[1] + p[3] - 1, 0xFF1A1226);

        for (LarpClient.Mod m : MODS) {
            LarpClient.State s = LarpClient.state(m.id());
            int[] pos = chipPos(p, s);
            boolean drag = m.id().equals(dragging);
            box(c, pos[0], pos[1], CHIP_W, CHIP_H,
                    s.enabled ? 0xFF7B2FF7 : 0xFF2B1E3D, drag ? 0xFFFFFFFF : ACCENT);
            int tw = textRenderer.getWidth(m.name());
            txt(c, m.name(), pos[0] + (CHIP_W - tw) / 2, pos[1] + 2, s.enabled ? 0xFFFFFFFF : MUTED);
        }

        // przycisk reset
        int rx = cx(), ry = cy() + ch() - 16, rw = 118, rh = 16;
        boolean hov = inside(mx, my, rx, ry, rw, rh);
        box(c, rx, ry, rw, rh, hov ? CARD_HOVER : CARD, 0xFF2A1450);
        txt(c, "Resetuj pozycje", rx + 8, ry + 4, TEXT);
    }

    // ------------------------------------------------------------------
    // Mysz i klawiatura
    // ------------------------------------------------------------------

    @Override
    public boolean mouseClicked(double mxD, double myD, int button) {
        int mx = (int) mxD, my = (int) myD;
        if (button == 0) {
            if (inside(mx, my, px + pw - 18, py + 5, 12, 12)) {
                close();
                return true;
            }
            for (int i = 0; i < TABS.length; i++) {
                if (inside(mx, my, px + 6, tabY(i), SIDE - 12, 22)) {
                    tab = i;
                    dragging = null;
                    return true;
                }
            }
            if (tab == 0) {
                for (int i = 0; i < MODS.size(); i++) {
                    if (inside(mx, my, cx(), rowY(i), cw(), 32)) {
                        LarpClient.State s = LarpClient.state(MODS.get(i).id());
                        s.enabled = !s.enabled;
                        LarpClient.save();
                        return true;
                    }
                }
            } else {
                if (inside(mx, my, cx(), cy() + ch() - 16, 118, 16)) {
                    LarpClient.resetPositions();
                    return true;
                }
                int[] p = preview();
                for (int i = MODS.size() - 1; i >= 0; i--) {
                    LarpClient.Mod m = MODS.get(i);
                    int[] pos = chipPos(p, LarpClient.state(m.id()));
                    if (inside(mx, my, pos[0], pos[1], CHIP_W, CHIP_H)) {
                        dragging = m.id();
                        grabDx = mx - pos[0];
                        grabDy = my - pos[1];
                        return true;
                    }
                }
            }
        }
        return super.mouseClicked(mxD, myD, button);
    }

    @Override
    public boolean mouseDragged(double mxD, double myD, int button, double dx, double dy) {
        if (dragging != null && tab == 1) {
            int[] p = preview();
            LarpClient.State s = LarpClient.state(dragging);
            s.fx = clamp01((mxD - grabDx - p[0]) / Math.max(1, p[2] - CHIP_W));
            s.fy = clamp01((myD - grabDy - p[1]) / Math.max(1, p[3] - CHIP_H));
            return true;
        }
        return super.mouseDragged(mxD, myD, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mxD, double myD, int button) {
        if (dragging != null) {
            dragging = null;
            LarpClient.save();
            return true;
        }
        return super.mouseReleased(mxD, myD, button);
    }

    private static double clamp01(double v) {
        return v < 0 ? 0 : Math.min(v, 1);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // P zamyka panel tak samo, jak go otwiera
        if (LarpClient.openKey() != null && LarpClient.openKey().matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
