Łapka Panel - mod klienta Fabric (Java Edition, Minecraft 1.21.4)

P - otwiera / zamyka czarno-fioletowy panel (zmiana klawisza: Opcje > Sterowanie > Łapka Panel).
    Domyslnie P jest tez "interakcjami spolecznymi" - panel ma pierwszenstwo,
    ale mozesz tez przypisac inny klawisz.

Zakladki (po lewej):
  Mody - przelaczniki FPS i Ping. Wlaczone elementy pokazuja sie na ekranie,
         np. "FPS 300" i "Ping 45 ms".
  GUI  - podglad ekranu. Przeciagnij FPS / Ping myszka w dowolne miejsce,
         pozycje zapisuja sie same. "Resetuj pozycje" przywraca domyslne.

Config: .minecraft/config/lapkapanel.json

BUDOWANIE
  Najlatwiej: szablon z https://fabricmc.net/develop (1.21.4), wrzuc do niego
  src/ oraz podmien build.gradle / gradle.properties / settings.gradle,
  potem: ./gradlew build  ->  build/libs/lapkapanel-1.0.0.jar
  Jar do .minecraft/mods razem z Fabric API dla 1.21.4.

BUDOWANIE BEZ INSTALOWANIA NICZEGO (GitHub)
  1. Zaloz konto na github.com i nowe repozytorium (np. lapkapanel).
  2. Wrzuc do niego zawartosc tego folderu (Add file > Upload files; folder .github tez!).
  3. Zakladka Actions > build > po ok. 2-3 min pobierz "lapkapanel-jar" (Artifacts).
  4. W zipie jest lapkapanel-1.0.0.jar - to jest mod (plik -sources.jar nie jest potrzebny).
